# Entity: Pictures

- name
- description
- source
- user

# Entity: User

- email
- password
- firstname
- lastname
